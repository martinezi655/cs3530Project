import { Meteor } from 'meteor/meteor';

Meteor.startup(() => {
  // code to run on server at startup

});


//if you comment this out, you can view the webpage properly

query_Students:function(studentName){
	console.log("Inside query_Students");
	console.log(studentName);
	var http = require('http');
	var MongoClient = require('mongodb').MongoClient;
	var url = "mongodb://localhost:3001/";
	var future = new Future();
	MongoClient.connect(url, function(err, db){
		if (err) throw err;
		var query = {"Student name" : studentName};
		console.log(query);
		var dbo = db.db("OnlineLearning");
		dbo.collection("Students").find(query).toArray(function(err, result) {
			if (err) throw err;
			var output ="";
			for(var entry in result){
			output+= result[entry]+"\n"
			}
			console.log(JSON.stringify(result));
			future.return(JSON.stringify(result));
			db.close();
		});
	});
return future.wait();
}


