import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';

import './main.html';



Template.query.events({
  'click button'(event, instance) {
console.log("Inside button click");
var name = document.getElementById("textStudentName").value;
console.log(name);
//document.getElementById("results").value = name;  Just tests that the value is getting collected from the form
var collection = "query_Students";
//var result = "verify";  This tests to see if we can write something to the textarea
var result = Meteor.call(collection.toString(), name, function(err, res)
	{
		if (err) console.log("error");
		else console.log("no error");
	});
document.getElementById("results").value = result;
  },
});
