import { Meteor } from 'meteor/meteor';

Meteor.startup(() => {
  // code to run on server at startup
});

/*
Supposedly some variation of this SHOULD work

query_Students: function(studentName){
	console.log("Inside query_Students");
	console.log(studentName);
	var http = require('http');
	var MongoClient = require('mongodb').MongoClient;
	var url = "mongodb://localhost:27017/";
	
	MongoClient.connect(url, function(err, db){
		if (err) throw err;
		var dbo = db.db("OnlineLearning");
		var query = {"Student name" : studentName};
		dbo.collection("Students").find(query).toArray(function(err, result) {
			if (err) throw err;
			console.log(result);
			db.close();
		});
	});
});
*/

