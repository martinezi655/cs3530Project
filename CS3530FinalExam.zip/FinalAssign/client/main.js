import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';

import './main.html';

/*
CS3530 Final Exam Assignment
Querying a MongoDB database and printing a specific value to an HTML form
Austin Lee
Jacob Mulroy
Patrick Murphy
Isaiah Martinez
D'Angelo Abell
*/

Template.query.events({
  'click button'(event, instance) {
console.log("Inside button click");
var name = document.getElementById("textStudentName").value;
console.log(name);
//document.getElementById("results").value = name;  Just tests that the value is getting collected from the form
var collection = "query_Students";
//var result = "verify";  This tests to see if we can write something to the textarea
Meteor.call(collection.toString(), name, function(err, res)
	{
		if (err) console.log(err);

		else
			{
			console.log(res);
			document.getElementById("results").value = res;
			}
	});

  },
}); 
