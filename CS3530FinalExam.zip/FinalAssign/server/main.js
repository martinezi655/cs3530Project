import { Meteor } from 'meteor/meteor';

/*
CS3530 Final Exam Assignment
Querying a MongoDB database and printing a specific value to an HTML form
Austin Lee
Jacob Mulroy
Patrick Murphy
Isaiah Martinez
D'Angelo Abell
*/

Meteor.startup(function() {
  // code to run on server at startup
 Future = Npm.require('fibers/future');
});

Meteor.methods({
query_Students:function(studentName){
	console.log("Inside query_Students");
	console.log(studentName);
	var http = require("http");
	var MongoClient = require("mongodb").MongoClient;
	var url = "mongodb://localhost:27017/";
	var future = new Future();
	MongoClient.connect(url, function(err, db){
		if (err) throw err;
		var query = {"Student Name":studentName};
		console.log(query);
		var dbo = db.db("OnlineLearning");
		dbo.collection("Students").find(query, {projection: {"Student Name": 0, _id: 0, "StudentID":0, "Address":0}}).toArray(function(err, result) {
			if (err) console.log(err);
			var output = "";
			for(var entry in result){
			var toclean = JSON.stringify(result[entry]);
			var scrubbed = toclean.substr(8,10);
			output+= scrubbed +"\n"
			}
			console.log("Output: " +output);
			console.log("JSON" + JSON.stringify(result));
			future.return(output);
			db.close();
		});
	});
return future.wait(); 
}
}) 
