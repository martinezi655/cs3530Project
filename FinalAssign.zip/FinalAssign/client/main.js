import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';

import './main.html';

Template.query.onCreated(function queryOnCreated() {
  // counter starts at 0
  //this.counter = new ReactiveVar(0);
});

Template.query.helpers({
  counter() {
    //return Template.instance().counter.get();
  },
});


Template.query.events({
  'click button'(event, instance) {
var name = document.getElementById("textStudentName").value;
//document.getElementById("results").value = name;  Just tests that the value is getting collected from the form
var collection = "query_Students";
Meteor.call(collection.toString(), name, function(err, res)
{
	if (err) console.log("MongoDB error");
	else console.log("Sucessful Query");
	});
  }, 
});
